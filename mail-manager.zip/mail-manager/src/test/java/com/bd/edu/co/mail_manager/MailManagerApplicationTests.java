package com.bd.edu.co.mail_manager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MailManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
